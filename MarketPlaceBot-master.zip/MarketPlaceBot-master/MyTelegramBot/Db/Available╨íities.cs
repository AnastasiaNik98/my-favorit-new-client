﻿using System;
using System.Collections.Generic;

namespace MyTelegramBot
{
    public partial class AvailableСities
    {
        public int Id { get; set; }
        public DateTime? Timestamp { get; set; }
        public string CityName { get; set; }
    }
}
