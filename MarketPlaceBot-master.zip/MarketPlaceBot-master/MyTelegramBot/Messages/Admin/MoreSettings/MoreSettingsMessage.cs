﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Telegram.Bot.Types.InlineKeyboardButtons;
using Telegram.Bot.Types.ReplyMarkups;
using Microsoft.EntityFrameworkCore;
using MyTelegramBot.Bot;
using MyTelegramBot.Messages.Admin;
using MyTelegramBot.Messages;
using MyTelegramBot.Bot.AdminModule;
using MyTelegramBot.Bot.Core;

namespace MyTelegramBot.Messages.Admin
{
    /// <summary>
    /// Доп. настройки
    /// </summary>
    public class MoreSettingsMessage:BotMessage
    {
        private BotInfo BotInfo { get; set; }
        private InlineKeyboardCallbackButton TimeWorkBtn { get; set; }

        private InlineKeyboardCallbackButton MethodsOfObtainingBtn { get; set; }

        private InlineKeyboardCallbackButton PaymentsSettingsBtn { get; set; }

        private InlineKeyboardCallbackButton PaymentsEnableBtn { get; set; }

        private InlineKeyboardCallbackButton AboutEditorBtn { get; set; }

        private InlineKeyboardCallbackButton VkEditorBtn { get; set; }

        private InlineKeyboardCallbackButton InstagramEditorBtn { get; set; }

        private InlineKeyboardCallbackButton ChatEditorBtn { get; set; }

        private InlineKeyboardCallbackButton ChannelEditorBtn { get; set; }

        private InlineKeyboardCallbackButton DeliveryPriceBtn { get; set; }

        private InlineKeyboardCallbackButton CurrencyEditorBtn { get; set; }

        private InlineKeyboardCallbackButton TelephoneVerifyEnableBtn { get; set; }

        public MoreSettingsMessage(BotInfo botInfo)
        {
            BotInfo = botInfo;
        }

        public override BotMessage BuildMsg()
        {
            TimeWorkBtn = BuildInlineBtn("Режим работы", BuildCallData(MoreSettingsBot.WorkTimeEditorCmd, MoreSettingsBot.ModuleName),base.ClockEmodji);

            MethodsOfObtainingBtn = BuildInlineBtn("Способы получения", BuildCallData(MoreSettingsBot.MethodOfObtaitingCmd, MoreSettingsBot.ModuleName),base.CarEmodji);

            PaymentsEnableBtn = BuildInlineBtn("Вкл/Выкл плат. систем", BuildCallData(MoreSettingsBot.EnablePaymentMethodEditorCmd, MoreSettingsBot.ModuleName),base.CreditCardEmodji);

            PaymentsSettingsBtn= BuildInlineBtn("Настройка плат. систем", BuildCallData(MoreSettingsBot.SettingsPaymentMethodCmd, MoreSettingsBot.ModuleName),base.CreditCardEmodji);

            AboutEditorBtn= BuildInlineBtn("О нас (ред.)", BuildCallData(MoreSettingsBot.AboutEditCmd, MoreSettingsBot.ModuleName),base.NoteBookEmodji);

            VkEditorBtn = BuildInlineBtn("VK.com (ред.)", BuildCallData(MoreSettingsBot.VkEditCmd, MoreSettingsBot.ModuleName),base.MobileEmodji);

            InstagramEditorBtn = BuildInlineBtn("Instagram (ред.)", BuildCallData(MoreSettingsBot.InstagramEditCmd, MoreSettingsBot.ModuleName), base.MobileEmodji);

            ChatEditorBtn = BuildInlineBtn("Чат (ред.)", BuildCallData(MoreSettingsBot.ChatEditCmd, MoreSettingsBot.ModuleName), base.MobileEmodji);

            ChannelEditorBtn = BuildInlineBtn("Канал (ред.)", BuildCallData(MoreSettingsBot.ChannelEditCmd, MoreSettingsBot.ModuleName), base.MobileEmodji);

            DeliveryPriceBtn= BuildInlineBtn("Стоимость доставки", BuildCallData(MoreSettingsBot.DeliveryPriceCmd, MoreSettingsBot.ModuleName), base.CashEmodji);

            CurrencyEditorBtn= BuildInlineBtn("Основная валюта", BuildCallData(MoreSettingsBot.CurrencyEditorCmd, MoreSettingsBot.ModuleName), base.CashEmodji);

            if(BotInfo.Configuration!=null && BotInfo.Configuration.VerifyTelephone)
                TelephoneVerifyEnableBtn = BuildInlineBtn("Требовать тел. при оформлении заказа", BuildCallData(MoreSettingsBot.TelephoneVerifyEnableCmd, MoreSettingsBot.ModuleName),base.CheckEmodji);

            else
                TelephoneVerifyEnableBtn = BuildInlineBtn("Требовать тел. при оформлении заказа", BuildCallData(MoreSettingsBot.TelephoneVerifyEnableCmd, MoreSettingsBot.ModuleName), base.UnCheckEmodji);

            BackBtn = BackToAdminPanelBtn();

            base.TextMessage = "Дополнительные настройки";

            SetKeyboad();


            return this;
           
        }

        private void SetKeyboad()
        {
            base.MessageReplyMarkup = new InlineKeyboardMarkup(
                new[]{
                new[]
                        {
                            TimeWorkBtn,MethodsOfObtainingBtn
                        },
                new[]
                        {
                            DeliveryPriceBtn,AboutEditorBtn
                        },
                new[]
                        {
                            VkEditorBtn,InstagramEditorBtn,
                        },
                new[]
                        {
                            ChannelEditorBtn,ChatEditorBtn
                        },
                new[]
                        {
                            PaymentsEnableBtn,PaymentsSettingsBtn
                        },
                new[]
                        {
                                CurrencyEditorBtn
                        },
                new[]
                        {
                                TelephoneVerifyEnableBtn
                        },
                new[]
                        {
                            BackBtn
                        },

                 });
        }
    }
}
