﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Telegram.Bot.Types;
using System.IO;
using System.Text;
using System.Net;
using Microsoft.EntityFrameworkCore;
namespace MyTelegramBot.Bot
{

}

